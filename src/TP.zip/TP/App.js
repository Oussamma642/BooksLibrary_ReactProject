
import { useState } from "react";
import JeuDe from "./Component/JeuDe";
function App()
{
  let lstImages = ['Dé.PNG', 'face1.PNG', 'face2.PNG', 'face3.PNG', 'face4.PNG', 'face5.PNG', 'face6.PNG', 'vide.PNG'];


  return (
    <>
      <JeuDe nbr={3}  lstimg={lstImages}/>
    </>
)

}

export default App;