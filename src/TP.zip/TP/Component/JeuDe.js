import { Component } from "react";

export default class JeuDe extends Component
{
    constructor(props)
    {
        // props.lstimg
        super(props);
        this.state ={
            Path: `images/${props.lstimg[0]}`,
            Face:0,
            nbrEssais:0
        }
    }

    Jouer = ()=>{
        let randomNumber = Math.floor(Math.random() * 6 + 1 );

        this.setState(
            {
                Path: `images/${this.props.lstimg[randomNumber]}`,
                Face: randomNumber,
                nbrEssais: this.state.nbrEssais + 1
            })
    }

    Initialiser=()=>{

        this.setState(
            {
                Path:`images/${this.props.lstimg[7]}`,
                Face:0,
                nbrEssais:0
            })
    }

    render()
    {
        return (
            <div style={{marginLeft:"40%"}}>

                <img src={this.state.Path} />

                <h1>Jeu De</h1>
                
                <h5>Face: {this.state.Face} </h5>
                
                <h5>Nombre d'essais: {this.state.nbrEssais} </h5>
                
                <p> {this.state.Face === this.props.nbr?'Bravo vous avez gagne':''} </p>

                <button style={{display:this.state.Face === this.props.nbr?'none':'block'}}  type="button" onClick={this.Jouer}>Jouer</button>

                <button style={{display:this.state.Face === this.props.nbr?'block':'none'}} type="button" onClick={this.Initialiser}>Initialiser</button>
            </div>
        );
    }
}
